#include "DHT.h"

#define DHTPIN 4     // Fio verde no pino 4
#define DHTTYPE DHT22 

DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(9600);
  Serial.println("--- Sistema Iniciado ---");
  dht.begin();
}

void loop() {
  // Espera 2 segundos para o sensor processar
  delay(2000);

  float t = dht.readTemperature();
  float h = dht.readHumidity();

  if (isnan(h) || isnan(t)) {
    Serial.println("Erro: Sensor desconectado ou pino errado!");
    return;
  }

  Serial.print("Umidade: ");
  Serial.print(h);
  Serial.print("% | Temp: ");
  Serial.print(t);
  Serial.println("°C");
} 
